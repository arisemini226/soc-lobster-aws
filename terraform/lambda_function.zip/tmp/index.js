exports.handler = async (event) => {
  console.log('SOC Security Response Lambda');
  return { statusCode: 200, body: JSON.stringify({ message: 'ok' }) };
};
